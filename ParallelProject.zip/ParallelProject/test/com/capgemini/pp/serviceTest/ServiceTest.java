package com.capgemini.pp.serviceTest;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.exception.BankAccountException;
import com.capgemini.pp.service.Service;

public class ServiceTest {

	 Service s=null;
	    Customer c=null;
	    @Test
	    public void createAccountTest() throws BankAccountException {
	        s=new Service();
	        c=new Customer();
	        c.setAccountNum(1);
	        c.setName("Ant");
	        boolean b=s.createAccount(c);
	        assertTrue("True", b);
	    }
	    
	    
	    @Test
	    public void showBalanceTest() throws BankAccountException {
	        s=new Service();
	        c=new Customer();
	        c.setAccountNum(1001);
	        s.createAccount(c);
	        double d=s.showBalance(1001);
	        assertEquals(1.0, d);
	           }
	    
	    
	    @Test
	    public void depositTest() throws BankAccountException {
	        s=new Service();
	        c=new Customer();
	        c.setAccountNum(1);
	        c.setName("Ant");
	        c.setBalance(100);
	        s.createAccount(c);
	        double d=s.deposit(1, 100);
	        assertEquals(0,d);
	    }
	    
	    @Test
	    public void withdrawTest() throws BankAccountException {
	        s=new Service();
	        c=new Customer();
	        c.setAccountNum(1);
	        c.setBalance(10);
	        s.createAccount(c);
	        s.deposit(1, 500);
	        double d=s.withdraw(1, 100);
	        assertEquals("not equal", 0, d);

	    }
	    
	    @Test
	    public void fundTransferTest() throws BankAccountException {
	        s=new Service();
	        c=new Customer();
	        c.setAccountNum(1);
	        c.setBalance(100);
	        s.createAccount(c);
	        c=new Customer();
	        c.setAccountNum(11);
	        c.setBalance(10);
	        s.createAccount(c);
	        String st=s.fundTransfer(1, 11, 5);
	        boolean b= true;
	        assertTrue(st,b);

}
}
