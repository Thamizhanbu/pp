package com.capgemini.pp.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.exception.BankAccountException;

public interface DaoInterface {

    public boolean createAccount(Customer c) throws BankAccountException ;
    public Customer customerDetails(Long accnum) throws BankAccountException ;
    public Customer showBalance(long accnum) throws BankAccountException ;
    public void deposit(Customer c) throws BankAccountException ;
    public void withdraw(Customer c) throws BankAccountException ;
    public int fundTransfer(long accnum) throws BankAccountException ;
    public Customer printTransaction(long accnum) throws BankAccountException ;
   	public List<Customer> getAllCustomers() throws BankAccountException;
    
}