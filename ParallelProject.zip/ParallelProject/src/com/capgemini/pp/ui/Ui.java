package com.capgemini.pp.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.exception.BankAccountException;
import com.capgemini.pp.service.*;

public class Ui {
	 //static long accountNumber=1000L;
    static Service s=new Service();
    
    public static void main(String[] args) throws BankAccountException  {
        try{
        
        Random r=new Random();
        long accountNumber= r.nextInt(1000000000);
        int choice,cont,age;
        long accnum,mobNum,aadhaar;
        double value,bal,balance,deposit,withdraw;
        String name,address,pan,fund,transaction;
        boolean result,b;
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
do {
    System.out.println("\nMenu\n");
    System.out.println("1.Create Account");
    System.out.println("2.Display Customer Details");
    System.out.println("3.Show Balance");
    System.out.println("4.Deposit");
    System.out.println("5.Withdraw");
    System.out.println("6.Fund Transfer");
    System.out.println("7.Print Transaction");
    System.out.println("8.Details of every customer");
    System.out.println("\nEnter your Choice");
    choice = sc.nextInt();
        
        
        switch (choice) {

        case 1:

            
            do{
                System.out.println("\nEnter Name [with Initial as capital]");
                name = sc2.nextLine();
                b=s.validateName(name);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\n name invalid");
                }
                }while(b==false);
            
            
            
            do{
                System.out.println("Enter Age [between 18 to 60]");
                age=sc.nextInt();
                b=s.validateAge(age);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\nage invalid");
                }
                }while(b==false);
            
            
            
            do{
                System.out.println("Enter Address");
                address = sc2.nextLine();
                b=s.validateAddress(address);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\naddress invalid");
                }
                }while(b==false);
            
            do{
                System.out.println("Enter mobile number [10 digits]");
                mobNum = sc.nextLong();
                String mob=Long.toString(mobNum);
                b=s.validateNum(mob);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("Mobile Number invalid");
                }
                }while(b==false);
            
            do{
                System.out.println("enter aadhaar number [12 digits]");
                aadhaar=sc.nextLong();
                String aadhaarNum=Long.toString(aadhaar);
                b=s.validateAadhaar(aadhaarNum);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\naadhaar invalid");
                }
                }while(b==false);
            
            do{
                System.out.println("enter Pan number [10 characters]");
                pan=sc.next();
                b=s.validatePan(pan);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("pan invalid");
                }
                }while(b==false); 
 
            do{
                System.out.println("\nEnter the amount to be added to your account");
                bal = sc.nextDouble();
                b=s.validateBalance(bal);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("Invalid amount");
                }
                }while(b==false);
            
            transaction="Transactions are";
            Customer c=new Customer();
            c.setAccountNum(accountNumber);
            c.setName(name);
            c.setAge(age);
            c.setAddress(address);
            c.setPan(pan);
            c.setAadhaar(aadhaar);
            c.setBalance(bal);
            c.setMobNum(mobNum);
            c.setTransaction(transaction);
            System.out.println("before");
            System.out.println(accountNumber);
            result=s.createAccount(c);
            System.out.println("after");
            accountNumber++;
            if(result)
            {
                System.out.println("Account created successfully and your account number is "+ c.getAccountNum());
            }
            else
            {
                System.out.println("Account not created");
            }
            break;
        case 2:
        	Customer c2=null;
        	System.out.println("enter account number");
            Long accNum2=sc.nextLong();
            int result2=s.validateAccountNumber(accNum2);
            if(result2==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            System.out.println("Customer details");
            c2=s.customerDetails(accNum2);
            System.out.println(c2);
            break;
            }
        case 3:
            System.out.println("enter account number");
            Long accNum3=sc.nextLong();
            int result3=s.validateAccountNumber(accNum3);
            if(result3==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            balance=s.showBalance(accNum3);
            System.out.println("Balance is "+balance);
            break;
            }
        case 4:
            System.out.println("enter account number");
            Long accNum4=sc.nextLong();
            int result4=s.validateAccountNumber(accNum4);
            if(result4==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            System.out.println("enter amount");
            value=sc.nextDouble();
            deposit=s.deposit(accNum4,value);
            System.out.println("Amount Deposited and Rs."+deposit+ " is balance ");
            break;
            }
        case 5:
            System.out.println("enter account number");
            Long accNum5=sc.nextLong();
            int result5=s.validateAccountNumber(accNum5);
            if(result5==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            System.out.println("enter amount");
            value=sc.nextDouble();
            withdraw=s.withdraw(accNum5,value);
            System.out.println("Money withdrawn and the balance is"+withdraw);
            break;
            }
        case 6:
            System.out.println("enter account number");
            Long accNum6=sc.nextLong();
            System.out.println("enter account number to be transferred");
            Long accNumber6=sc.nextLong();
            int res6=s.validateAccountNumber(accNum6);
            int result6=s.validateAccountNumber(accNumber6);
            if(res6==0){
            	System.out.println("Invalid Source Account Number");
            	break;
            }
            else if(result6==0){
            	System.out.println("Invalid Destination Account Number");
            	break;
            }
            else{
            System.out.println("enter amount");
            value=sc.nextDouble();
            fund=s.fundTransfer(accNum6,accNumber6,value);
            System.out.println(fund);
            break;
            }
        case 7:
            System.out.println("enter account number");
            Long accNum7=sc.nextLong();
            System.out.println("My Transactions\n");
            System.out.println(s.printTransaction(accNum7));
            break;
        case 8:
            System.out.println("All Customer Details");
            List<Customer> custList;
    		try {
    			custList =s.getAllCustomers();
    			Iterator<Customer> iterator=custList.iterator();
    			while(iterator.hasNext())
    			{
    			System.out.println(iterator.next());	
    			}			
    			
    		} catch (BankAccountException e) {			
    			e.printStackTrace();
    		}
            break;
        default:
            System.out.println("wrong choice");
            break;
        }
        System.out.println("Are you want to continue transaction?(press 1 for yes)");
        cont=sc.nextInt();
        
    }while(cont==1);
sc.close();
sc2.close();
        }
        
        catch(Exception e)
        {
            System.out.println(e);
            throw new BankAccountException("Exception Occured");
        }

    }
}





