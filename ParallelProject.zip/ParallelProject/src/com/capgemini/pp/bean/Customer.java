package com.capgemini.pp.bean;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.sun.istack.internal.NotNull;

@Entity
public class Customer {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long accountNum;
	private String name;
	@NotNull
	private int age;
	private String address; 
	private String pan;
	private long aadhaar;
	private double balance;
	private long mobNum;
	private String transaction;

	
    public Customer() {
		
	}
    
    
    
	public Customer(long accountNum, String name, int age, String address,
			String pan, long aadhaar, double balance, long mobNum, String transaction) {
		super();
		this.accountNum = accountNum;
		this.name = name;
		this.age = age;
		this.address = address;
		this.pan = pan;
		this.aadhaar = aadhaar;
		this.balance = balance;
		this.mobNum = mobNum;
		this.transaction=transaction;
	}



	public long getAccountNum() {
        return accountNum;
    }
    public void setAccountNum(long accountNum) {
        this.accountNum = accountNum;
    }
    
	 public void setName(String name){
	        this.name=name;
	    }
	    public String getName(){
	        return this.name;
	    }
	    

	    public int getAge() {
	        return age;
	    }
	    public void setAge(int age) {
	        this.age = age;
	    }

	    
	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }
	     
	    
	    
	    public String getPan() {
	        return pan;
	    }
	    public void setPan(String pan) {
	        this.pan = pan;
	    }
	    
	    
	    public long getAadhaar() {
	        return aadhaar;
	    }
	    public void setAadhaar(long aadhaar) {
	        this.aadhaar = aadhaar;
	    }
	    
	    
	    public double getBalance() {
	        return balance;
	    }
	    public void setBalance(double balance) {
	        this.balance = balance;
	    }
	    
	    public long getMobNum() {
	        return mobNum;
	    }
	    public void setMobNum(long mobNum) {
	        this.mobNum = mobNum;
	    }
	    	    
	    public String getTransaction() {
			return transaction;
		}



		public void setTransaction(String transaction) {
			this.transaction = transaction;
		}



		@Override
	    public String toString(){
	        return "\nName: "+name+ 
	                "\nAccount Number: "+accountNum+
	                "\nBalance: "+balance+  
	                "\nAge: "+age+
	                "\nMobile Number: "+mobNum+
	                "\nAddress: "+address+
	                "\nAadhaar Number: "+aadhaar+
	                "\nPan Number: "+pan+"  "+transaction;
	        
	    }

	}
