package com.capgemini.pp.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.pp.bean.Customer;
import com.capgemini.pp.dao.*;
import com.capgemini.pp.exception.BankAccountException;

public class Service implements ServiceInterface {
	   
    Dao d=null;
    double check;
    
    public int validateAccountNumber(Long accnum){
    	d=new Dao();
		return d.validateAccountNumber(accnum);
    	
    }
    public boolean validateName(String name2) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
    Matcher nameMatch=name.matcher(name2);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAge(int age) throws BankAccountException
    {
    boolean flag=false;
    if(age>=18&&age<=60)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAddress(String address) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("(?=,*[0-9])[A-Za-z0-9,\\s]+");
    Matcher nameMatch=name.matcher(address);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }

    
    public boolean validateNum(String mobnum) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[0-9]{10}");
    Matcher nameMatch=name.matcher(mobnum);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAadhaar(String aadhaar) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[0-9]{12}");
    Matcher nameMatch=name.matcher(aadhaar);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    
    public boolean validatePan(String pan) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[A-Z0-9]{10}");
    Matcher nameMatch=name.matcher(pan);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    

    
    public boolean validateBalance(double balance) throws BankAccountException
    {
    boolean flag=false;
    if(balance>=0)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    public boolean createAccount(Customer c) throws BankAccountException {
       d=new Dao();
       return d.createAccount(c);
    }


    
    public Customer customerDetails(Long accnum) throws BankAccountException {
    	Customer c2=null;
    	d=new Dao();
    	c2=d.customerDetails(accnum);
        return c2;
    }


    public double showBalance(long accnum) throws BankAccountException {
    	d=new Dao();
        double bal = 0;    
        Customer c3= d.showBalance(accnum);
        bal = c3.getBalance();
      return bal;
    }
    
    public double deposit(long accnum,double amount) throws BankAccountException{
    	d=new Dao();
        double dep = 0;
        Customer c4= d.customerDetails(accnum);
             dep = c4.getBalance() + amount;
             c4.setBalance(dep); 
             String s1 =c4.getTransaction().concat("\n"+amount+" is Deposited");
             c4.setTransaction(s1);
             d.deposit(c4);
            
      return dep;

    }
    
    
    public double withdraw(long accnum, double amount) throws BankAccountException{
    	d=new Dao();
        double wd = 0;
        

        Customer c5= d.customerDetails(accnum);
        if (amount<=c5.getBalance() ) {
            wd = c5.getBalance() - amount;
            c5.setBalance(wd);
            String s2 =c5.getTransaction().concat("\n"+amount+" is Withdrawn");
            c5.setTransaction(s2);
            d.withdraw(c5);
        }
        else
        {
          throw new BankAccountException("Invalid account");
        }

      
      return wd;

    }
    
    public String fundTransfer(long accnum,long accnum2, double amount) throws BankAccountException  {
        
    	d=new Dao();
        double check1,check2;
        String fund=null;
        double b1=0,b2=0;
        b1=withdraw(accnum,amount);
        if(b1!=0) {
            b2=deposit(accnum2,amount);
            fund="After the fund transfer:\n Balance in the source account is "+b1+
                    " \n Balance in the destination account is "+b2;
            }

       else
        {
            fund="Transfer failed";
        }
        return fund;
    }
    
    public String printTransaction(long accnum) throws BankAccountException{
    	System.out.println("hi1");
    	Customer c6=d.customerDetails(accnum);	
    	 System.out.println("hi2");
    	 String value=c6.getTransaction();
    	 System.out.println("hi3");
        return value;
    }

    
	@Override
	public List<Customer> getAllCustomers() throws BankAccountException {
		d=new Dao();
		return d.getAllCustomers();
	}
    
}