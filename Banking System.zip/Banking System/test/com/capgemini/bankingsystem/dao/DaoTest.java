package com.capgemini.bankingsystem.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.bankingsystem.bean.Account;
import com.capgemini.bankingsystem.dao.Dao;
import com.capgemini.bankingsystem.exception.BankAccountException;

public class DaoTest {

	Dao d=null;
	Account c=null;
	@Test
	public void testCreateAccount() throws BankAccountException {
       
		d=new Dao();
		c=new Account();
		c.setAccountNum(100000L);
        c.setName("tom");
        c.setAge(24);
        c.setAddress("chennai, TamilNadu");
        c.setPan("HRT987LP01");
        c.setAadhaar(789654456852L);
        c.setBalance(200);
        c.setMobNum(9874563210L);
        c.setTransaction("My transaction");
        boolean b=d.createAccount(c);
        assertTrue("True", b);
	}

	@Test
	public void testShowBalance() throws BankAccountException {
        
		d=new Dao();
        double d1=d.showBalance(100000L);
        assertEquals(200.0, d1,0);
	}

	@Test
	public void testDeposit() throws BankAccountException {
		d=new Dao();
        c=new Account();
        double d2=d.deposit(c);
        assertNotEquals(200.0, d2, 0);
	}

	@Test
	public void testWithdraw() throws BankAccountException {
		d=new Dao();
		c=new Account();
		c.setBalance(200);
        double d4=d.withdraw(c);
        assertEquals(200.0, d4, 0);
	}

	
	@Test
	public void testFundTransfer() throws BankAccountException {
		Account s=new Account();
		d=new Dao();
		 boolean b=d.fundTransfer(s);
		 assertTrue("True", b);
	 		
	}



}
