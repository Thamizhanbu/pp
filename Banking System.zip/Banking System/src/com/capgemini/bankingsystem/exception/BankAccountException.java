package com.capgemini.bankingsystem.exception;

public class BankAccountException extends Exception {

    public BankAccountException(String msg) {
        
        super(msg);
    }
}
