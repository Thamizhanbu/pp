package com.capgemini.bankingsystem.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;


@Entity
public class Account {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long accountNumber;
	private String name;
	@NotNull
	private int age;
	private String address; 
	private String panNumber;
	private long aadhaarNumber;
	private double balance;
	private long mobileNumber;
	private String transactionDetails;


    public Account() {
		
	}
        
	
		public long getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPanNumber() {
		return panNumber;
	}


	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}


	public long getAadhaarNumber() {
		return aadhaarNumber;
	}


	public void setAadhaarNumber(long aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public long getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public String getTransactionDetails() {
		return transactionDetails;
	}


	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = transactionDetails;
	}


	}
