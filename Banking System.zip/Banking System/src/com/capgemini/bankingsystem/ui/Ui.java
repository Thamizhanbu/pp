package com.capgemini.bankingsystem.ui;

import java.util.Scanner;
import java.util.Random;

import com.capgemini.bankingsystem.bean.Account;
import com.capgemini.bankingsystem.exception.BankAccountException;
import com.capgemini.bankingsystem.service.*;

public class Ui {
	 
    static Service serviceClassObject=null;
    
    public static void main(String[] args) throws BankAccountException  {

        Scanner scannerObject1 = new Scanner(System.in);
        Scanner scannerObject2 = new Scanner(System.in);
        
        try{

        Random randomNumberObject=new Random();
        
        long accountNumber= randomNumberObject.nextInt(1000000000);
        String name,address,panNumber;
        int age;
        long mobileNumber,aadhaarNumber;
        
        int choice;
        
        double depositAmount,withdrawAmount,fundTransferAmount;
        double openingBalance,accountBalance,balanceAfterDeposit,balanceAfterWithdraw;
        String fundTransferResultDetail,transactionDetails;
        
        

        while(true) {
    System.out.println("\nMenu\n");
    System.out.println("1.Create Account");
    System.out.println("2.Show Balance");
    System.out.println("3.Deposit");
    System.out.println("4.Withdraw");
    System.out.println("5.Fund Transfer");
    System.out.println("6.Print Transaction");
    System.out.println("7.Exit");
    System.out.println("\nEnter your Choice");
    
    choice = scannerObject1.nextInt();
        
        
        switch (choice) {

        case 1:
        	serviceClassObject=new Service();
        	Account accountClassObject=new Account();
        	boolean createAccountOperationResult;
        	boolean validationResult;
        	
            
            do{
                System.out.println("\nEnter Name [with Initial as capital]");
                name = scannerObject2.nextLine();
                validationResult=serviceClassObject.validateName(name);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\n name invalid");
                }
                }while(validationResult==false);
            
            
            
            do{
                System.out.println("Enter Age [between 18 to 60]");
                age=scannerObject1.nextInt();
                validationResult=serviceClassObject.validateAge(age);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\nage invalid");
                }
                }while(validationResult==false);
            
            
            
            do{
                System.out.println("Enter Address");
                address = scannerObject2.nextLine();
                validationResult=serviceClassObject.validateAddress(address);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\naddress invalid");
                }
                }while(validationResult==false);
            
            do{
                System.out.println("Enter mobile number [10 digits]");
                mobileNumber = scannerObject1.nextLong();
                String mob=Long.toString(mobileNumber);
                validationResult=serviceClassObject.validateNum(mob);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("Mobile Number invalid");
                }
                }while(validationResult==false);
            
            do{
                System.out.println("enter aadhaar number [12 digits]");
                aadhaarNumber=scannerObject1.nextLong();
                String aadhaarNum=Long.toString(aadhaarNumber);
                validationResult=serviceClassObject.validateAadhaar(aadhaarNum);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\naadhaar invalid");
                }
                }while(validationResult==false);
            
            do{
                System.out.println("enter Pan number [10 characters]");
                panNumber=scannerObject1.next();
                validationResult=serviceClassObject.validatePan(panNumber);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("pan invalid");
                }
                }while(validationResult==false); 
 
            do{
                System.out.println("\nEnter the amount to be added to your account");
                openingBalance = scannerObject1.nextDouble();
                validationResult=serviceClassObject.validateBalance(openingBalance);
                if(validationResult==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("Invalid amount");
                }
                }while(validationResult==false);
            
            transactionDetails="My Transactions";
            
            
            accountClassObject.setAccountNumber(accountNumber);
            accountClassObject.setName(name);
            accountClassObject.setAge(age);
            accountClassObject.setAddress(address);
            accountClassObject.setPanNumber(panNumber);
            accountClassObject.setAadhaarNumber(aadhaarNumber);
            accountClassObject.setBalance(openingBalance);
            accountClassObject.setMobileNumber(mobileNumber);
            accountClassObject.setTransactionDetails(transactionDetails);
            
            
            
            createAccountOperationResult=serviceClassObject.createAccount(accountClassObject);
            
            if(createAccountOperationResult)
            {
                System.out.println("Account created successfully and your account number is "+ accountClassObject.getAccountNumber());
            }
            else
            {
                System.out.println("Account not created");
            }
            accountNumber++;
            break;

        case 2:
        	serviceClassObject=new Service();
            System.out.println("enter account number");
            Long accountNumberForShowBalance=scannerObject1.nextLong();
            int showBalanceAccountNumberValidationResult=serviceClassObject.validateAccountNumber(accountNumberForShowBalance);
            if(showBalanceAccountNumberValidationResult==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            	accountBalance=serviceClassObject.showBalance(accountNumberForShowBalance);
            System.out.println("Balance is "+accountBalance);
            break;
            }
            
        case 3:
        	serviceClassObject=new Service();
            System.out.println("enter account number");
            Long accountNumberForDeposit=scannerObject1.nextLong();
            int depositAccountNumberValidationResult=serviceClassObject.validateAccountNumber(accountNumberForDeposit);
            if(depositAccountNumberValidationResult==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            System.out.println("enter amount");
            depositAmount=scannerObject1.nextDouble();
            balanceAfterDeposit=serviceClassObject.deposit(accountNumberForDeposit,depositAmount);
            System.out.println("Amount Deposited and Rs."+balanceAfterDeposit+ " is balance ");
            break;
            }
            
        case 4:
        	serviceClassObject=new Service();
            System.out.println("enter account number");
            Long accountNumberForWithdraw=scannerObject1.nextLong();
            int withdrawAccountNumberValidationResult=serviceClassObject.validateAccountNumber(accountNumberForWithdraw);
            if(withdrawAccountNumberValidationResult==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            System.out.println("enter amount");
            withdrawAmount=scannerObject1.nextDouble();
            balanceAfterWithdraw=serviceClassObject.withdraw(accountNumberForWithdraw,withdrawAmount);
            System.out.println("Money withdrawn and the balance is"+balanceAfterWithdraw);
            break;
            
            }
        case 5:
        	serviceClassObject=new Service();
        	
            System.out.println("enter account number");
            Long sourceAccountNumberForFundTransfer=scannerObject1.nextLong();          
            int sourceAccountNumberValidationResult=serviceClassObject.validateAccountNumber(sourceAccountNumberForFundTransfer);
            if(sourceAccountNumberValidationResult==0){
            	System.out.println("Invalid Source Account Number");
            	break;
            }
            else{            
            	System.out.println("enter account number to be transferred");
                Long destinationAccountNumberForFundTransfer=scannerObject1.nextLong();
                int destinationAccountNumberValidationResult=serviceClassObject.validateAccountNumber(destinationAccountNumberForFundTransfer);
            
                if(destinationAccountNumberValidationResult==0){
            	System.out.println("Invalid Destination Account Number");
            	break;
                }
                else{
                	System.out.println("enter amount");
                	fundTransferAmount=scannerObject1.nextDouble();
                	fundTransferResultDetail=serviceClassObject.fundTransfer(sourceAccountNumberForFundTransfer,destinationAccountNumberForFundTransfer,fundTransferAmount);
                	System.out.println(fundTransferResultDetail);
                	break;
                }
            }
            
        case 6:
        	serviceClassObject=new Service();
            System.out.println("enter account number");
            Long accountNumberForPrintTransaction=scannerObject1.nextLong();
            int printTransactionAccountNumberValidationResult=serviceClassObject.validateAccountNumber(accountNumberForPrintTransaction);
            if(printTransactionAccountNumberValidationResult==0){
            	System.out.println("Invalid Account Number");
            	break;
            }
            else{
            	 System.out.println(serviceClassObject.printTransaction(accountNumberForPrintTransaction));
            break;
            }
           
        case 7:
        	System.exit(0);
        	break;
       
        default:
            System.out.println("wrong choice");
            break;
        }
    }

        }
        
        catch(Exception e)
        {
            System.out.println(e);
            throw new BankAccountException("Exception is Occured");
        }
        finally{
        	 scannerObject1.close();
             scannerObject2.close();
        }

    }
}





