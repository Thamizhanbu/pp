package com.capgemini.bankingsystem.service;

import com.capgemini.bankingsystem.bean.Account;
import com.capgemini.bankingsystem.exception.BankAccountException;

public interface ServiceInterface {
    public boolean createAccount(Account accountClassObject) throws BankAccountException;
    public double showBalance(long accountNumberForShowBalance) throws BankAccountException;
    public double deposit(long accountNumberForDeposit,double depositAmount) throws BankAccountException;
    public double withdraw(long accountNumberForWithdraw,double withdrawAmount)  throws BankAccountException;
    public String fundTransfer(long sourceAccountNumberForFundTransfer,long destinationAccountNumberForFundTransfer,double fundTransferAmount) throws BankAccountException;
    public String printTransaction(long accountNumberForPrintTransaction) throws BankAccountException;
    
}