package com.capgemini.bankingsystem.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bankingsystem.bean.Account;
import com.capgemini.bankingsystem.dao.*;
import com.capgemini.bankingsystem.exception.BankAccountException;

public class Service implements ServiceInterface {
	   
    Dao d=null;
    double check;
    
    public int validateAccountNumber(Long accnum){
    	d=new Dao();
		return d.validateAccountNumber(accnum);
    	
    }
    public boolean validateName(String name2) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
    Matcher nameMatch=name.matcher(name2);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAge(int age) throws BankAccountException
    {
    boolean flag=false;
    if(age>=18&&age<=60)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAddress(String address) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("(?=,*[0-9])[A-Za-z0-9,\\s]+");
    Matcher nameMatch=name.matcher(address);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }

    
    public boolean validateNum(String mobnum) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[0-9]{10}");
    Matcher nameMatch=name.matcher(mobnum);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAadhaar(String aadhaar) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[0-9]{12}");
    Matcher nameMatch=name.matcher(aadhaar);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    
    public boolean validatePan(String pan) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[A-Z0-9]{10}");
    Matcher nameMatch=name.matcher(pan);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    

    
    public boolean validateBalance(double balance) throws BankAccountException
    {
    boolean flag=false;
    if(balance>=0)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    public boolean createAccount(Account accountClassObject) throws BankAccountException {
       d=new Dao();
       return d.createAccount(accountClassObject);
    }


    
    public Account customerDetails(Long accnum) throws BankAccountException {
    	Account accountClassObject=null;
    	d=new Dao();
    	accountClassObject=d.customerDetails(accnum);
        return accountClassObject;
    }


    public double showBalance(long accountNumberForShowBalance) throws BankAccountException {
    	d=new Dao();
        double bal = 0;    
        bal = d.showBalance(accountNumberForShowBalance);
      return bal;
    }
    
    public double deposit(long accountNumberForDeposit,double depositAmount) throws BankAccountException{
    	d=new Dao();
        double dep = 0;
        Account accountClassObject= d.customerDetails(accountNumberForDeposit);
             dep = accountClassObject.getBalance() + depositAmount;
             accountClassObject.setBalance(dep); 
             String s1 =accountClassObject.getTransactionDetails().concat("\n"+depositAmount+" is Deposited");
             accountClassObject.setTransactionDetails(s1);          
      return d.deposit(accountClassObject);

    }
    
    
    public double withdraw(long accountNumberForWithdraw,double withdrawAmount) throws BankAccountException{
    	d=new Dao();
        double wd = 0;
        

        Account accountClassObject= d.customerDetails(accountNumberForWithdraw);
        if (withdrawAmount<=accountClassObject.getBalance() ) {
            wd = accountClassObject.getBalance() - withdrawAmount;
            accountClassObject.setBalance(wd);
            String s2 =accountClassObject.getTransactionDetails().concat("\n"+withdrawAmount+" is Withdrawn");
            accountClassObject.setTransactionDetails(s2);
            return d.withdraw(accountClassObject);
        }
        else
        {
          throw new BankAccountException("Invalid amount");
        }

    }
    
    public String fundTransfer(long sourceAccountNumberForFundTransfer,long destinationAccountNumberForFundTransfer,double fundTransferAmount) throws BankAccountException  {
        
    	d=new Dao();
        String fund=null;
        double b1=0,b2=0;
        boolean res1,res2;
        b1=withdraw(sourceAccountNumberForFundTransfer,fundTransferAmount);
        if(b1!=0) {
            b2=deposit(destinationAccountNumberForFundTransfer,fundTransferAmount);
            fund="After the fund transfer:\n Balance in the source account is "+b1+
                    " \n Balance in the destination account is "+b2;
            
            Account accountClassObject1=d.customerDetails(sourceAccountNumberForFundTransfer);
            String s1=accountClassObject1.getTransactionDetails().concat("\nThis last transaction of amount "+fundTransferAmount+"is transferred from your account ("+sourceAccountNumberForFundTransfer+") to "+" the account of "+destinationAccountNumberForFundTransfer);
            accountClassObject1.setTransactionDetails(s1);
            res1=d.fundTransfer(accountClassObject1);
            
            Account accountClassObject2=d.customerDetails(destinationAccountNumberForFundTransfer);
            String s2=accountClassObject2.getTransactionDetails().concat("\nThis last transaction of amount "+fundTransferAmount+"is transferred from the account of "+sourceAccountNumberForFundTransfer+" to "+" your account ("+destinationAccountNumberForFundTransfer)+")";
            accountClassObject2.setTransactionDetails(s2);
            res2=d.fundTransfer(accountClassObject2);
            
            if(res1==true&&res2==true){
            	return fund;
            }
            else
            {
            	return "fund transfer not added";
            }
            
        }

       else
        {
            return "Transfer failed";
        }
    }
    
    public String printTransaction(long accountNumberForPrintTransaction) throws BankAccountException{

    	Account accountClassObject=d.printTransaction(accountNumberForPrintTransaction);	
    	 return accountClassObject.getTransactionDetails();
    }

    
}