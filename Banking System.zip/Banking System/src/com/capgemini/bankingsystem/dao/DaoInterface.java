package com.capgemini.bankingsystem.dao;

import java.util.List;

import com.capgemini.bankingsystem.bean.Account;
import com.capgemini.bankingsystem.exception.BankAccountException;

public interface DaoInterface {

    public boolean createAccount(Account c) throws BankAccountException ;
    public double showBalance(long accnum) throws BankAccountException ;
    public double deposit(Account c) throws BankAccountException ;
    public double withdraw(Account c) throws BankAccountException ;
    public boolean fundTransfer(Account c) throws BankAccountException ;
    public Account printTransaction(long accnum) throws BankAccountException ;
    
}