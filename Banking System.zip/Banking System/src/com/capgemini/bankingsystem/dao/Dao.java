package com.capgemini.bankingsystem.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.bankingsystem.bean.Account;
import com.capgemini.bankingsystem.exception.BankAccountException;
import com.capgemini.bankingsystem.utility.JPAUtil;

public class Dao implements DaoInterface {
	private EntityManager entityManager;
	
	
	public int validateAccountNumber(Long accnum){
		
		entityManager=JPAUtil.getEntityManager();
		Account accountClassObject=entityManager.find(Account.class, accnum);
		if(accountClassObject==null)
		{
			return 0;
		}
		else
		{
		return 1;
	}
	}
	
	
	

	@Override
	public boolean createAccount(Account accountClassObject) throws BankAccountException {
		EntityManager entityManager = null;	
		try{
			boolean result=false;
			entityManager=JPAUtil.getEntityManager();
			EntityTransaction transaction=entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(accountClassObject);
			transaction.commit();
	        result=true;
	        return result;
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
	
	
	
	public Account customerDetails(Long accnum) throws BankAccountException {
		try{

			entityManager=JPAUtil.getEntityManager();
			Account c=entityManager.find(Account.class, accnum);
			return c;
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
	
	
	@Override
	public double showBalance(long accnum) throws BankAccountException {
		try{
			entityManager=JPAUtil.getEntityManager();
			Account accountClassObject=entityManager.find(Account.class, accnum);
			return accountClassObject.getBalance();
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
		
	@Override 
	public double deposit(Account accountClassObject) throws BankAccountException{
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(accountClassObject);
			entityManager.getTransaction().commit();
			return accountClassObject.getBalance();
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}
	
	@Override public double withdraw(Account accountClassObject) throws BankAccountException{
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(accountClassObject);
			entityManager.getTransaction().commit();
			return accountClassObject.getBalance();
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}
	
	
	@Override
	public boolean fundTransfer(Account accountClassObject) throws BankAccountException {
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(accountClassObject);
			entityManager.getTransaction().commit();
			return true;
			
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}




	@Override
	public Account printTransaction(long accnum) throws BankAccountException {
		try{

			entityManager=JPAUtil.getEntityManager();
			Account accountClassObject=entityManager.find(Account.class, accnum);
			return accountClassObject;
		}catch(PersistenceException e) {
			throw new BankAccountException(e.getMessage());
		}finally {
			entityManager.close();
		}
	}
	

	


	    
}